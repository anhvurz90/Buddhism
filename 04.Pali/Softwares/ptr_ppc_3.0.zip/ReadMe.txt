Pali Text Reader for PocketPC v3.0
(c) PavelBure, 2006-2007. Freeware.
pavelbure@hotmail.ru

Installation procedure:

If you are upgrading from version 2.0
1. Run PTR_PPC_Setup.exe on your PC to install the updated version.

If you are installing for the first time:
1. Run PTR_PPC_Setup.exe on your PC to install the application.
2. Extract 3 files from Fonts.zip and copy them to windows\fonts directory on the device.
This will install CN-Times font.
3. Download Pali Canon library for Pocket PC (PaliCanon_PPC_Setup.exe).
Run it on your PC to install the library on the PocketPC.

!!! Soft-reset the device before you run PaliTextReader for the first time !!!

